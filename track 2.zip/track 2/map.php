<?php
session_start();
set_time_limit(120);

$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];

// Pick a random icon for each pet marker
function getRandomIcon() {
    $icons = [
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png'
    ];
    return $icons[array_rand($icons)];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Leaflet Map with Clickable Markers, Geofencing, and Search</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #E7FBE6;
        }


    .h-auto.w-full.flex.items-center.justify-end {
    justify-content: center; /* Center horizontally */
}

.dt {
    font-size: 20px;
    position: fixed;
    color: #343131;
    padding: 20px 20px;
    border-radius: 5px;
    border: 1px solid black;
    background-color: transparent;
    margin: 30px;
    text-align: center; /* Center the text inside the element */
}

@media (max-width: 700px) {
    .dt {
        font-size: 14px;
        padding: 10px 10px;
    }
            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background color */
            }
        }

        .col2 {
            background-color: blue;
            width: 100vw;
        }

        .container2  {
            display: flex;
            flex-direction: row;
        }

        .date-time {
    background-color: transparent; /* Makes the background transparent */
    border: 1px solid black; /* Adds a black border */
    height: 5rem; /* Sets the height of the element */
}

        #sidebar {
            width: 20%; /* Adjust width as needed */
            height: 100vh; /* Full height */
            background-color: white; /* Sidebar background color */
        }
        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }

        @media (max-width: 700px) {
            
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                /* Adjust width as needed */
                height: 100vh;
                /* Full height */
                background-color: white;
                /* Sidebar background colo  r */
            }
        }

    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <div class="grid grid-rows-7 h-full">
                <div class="h-auto w-full flex items-center justify-end">
                    <div id="datetime" class="dt">
                    </div>
                </div>
                <div id="map" class="row-span-6">
                </div>
            </div>
        </div>
    </div>




    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
    <script>
        var map = L.map('map').setView([51.505, -0.09], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19
        }).addTo(map);

        var ownerMarker = null;
        var ownerGeofence = null;
        var geofenceRadius = 100; // radius in meters
        var petMarkers = [];

        function updateLocation(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;

            if (ownerMarker) {
                ownerMarker.setLatLng([lat, lng]);
                if (ownerGeofence) {
                    ownerGeofence.setLatLng([lat, lng]);
                }
            } else {
                ownerMarker = L.marker([lat, lng]).addTo(map)
                    .bindPopup('Owner').openPopup();

                ownerGeofence = L.circle([lat, lng], {
                    radius: geofenceRadius,
                    color: 'red',
                    fillColor: '#f03',
                    fillOpacity: 0.5
                }).addTo(map);
            }

            map.setView([lat, lng], 13);
        }

        function handleLocationError(error) {
            alert('Error: ' + error.message);
        }

        if (navigator.geolocation) {
            navigator.geolocation.watchPosition(updateLocation, handleLocationError, {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            });
        } else {
            alert('Geolocation is not supported by your browser.');
        }

        var icons = [
            {
                iconUrl: './icon/gps.png',
                iconSize: [30, 40],     // Size of the icon image
                iconAnchor: [12, 41],   // Point of the icon which will correspond to marker's location
                popupAnchor: [1, -34]   // Point from which the popup should open relative to the iconAnchor
            },
            {
                iconUrl: './icon/location.png',
                iconSize: [30, 40],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            },
            {
                iconUrl: './icon/map.png',
                iconSize: [30, 40],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34]
            }
        ];

        function getRandomIconUrl() {
            var randomIcon = icons[Math.floor(Math.random() * icons.length)];
            return L.icon({
                iconUrl: randomIcon.iconUrl,
                iconSize: randomIcon.iconSize,
                iconAnchor: randomIcon.iconAnchor,
                popupAnchor: randomIcon.popupAnchor
            });
        }

        function addMarker(lat, lng, name) {
            var marker = L.marker([lat, lng], { icon: getRandomIconUrl() }).addTo(map)
                .bindPopup(name);

            var pet = {
                name: name,
                marker: marker
            };
            petMarkers.push(pet);

            // Send data to history.php
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "history.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send("lat=" + lat + "&lng=" + lng + "&name=" + name + "&timestamp=" + new Date().toISOString());
        }

        function isInsideGeofence(lat, lng) {
            if (!ownerMarker) {
                return false;
            }
            var distance = map.distance(ownerMarker.getLatLng(), L.latLng(lat, lng));
            return distance <= geofenceRadius;
        }

        function isPetRegistered() {
            return <?php echo json_encode(count($registeredPets) > 0); ?>;
        }

        function getRegisteredPetNames() {
            var names = <?php echo json_encode(array_column($registeredPets, 'petName')); ?>;
            return names;
        }

        map.on('click', function (e) {
            if (!isPetRegistered()) {
                alert('Please register a pet before adding markers.');
                window.location.href = 'pet-registration.php';
                return;
            }

            var lat = e.latlng.lat;
            var lng = e.latlng.lng;

            if (isInsideGeofence(lat, lng)) {
                var registeredPetNames = getRegisteredPetNames();
                var name = prompt('Enter marker name:');
                if (name && registeredPetNames.includes(name)) {
                    addMarker(lat, lng, name);
                } else {
                    alert('Invalid pet name. Please enter a registered pet name.');
                }
            } else {
                alert('Marker must be placed within the geofence.');
            }
        });

        function updateDateTime() {
            var now = new Date();
            var options = {
                timeZone: 'Asia/Manila',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            var formatter = new Intl.DateTimeFormat([], options);
            document.getElementById('datetime').innerHTML = formatter.format(now);
        }

        setInterval(updateDateTime, 1000); // Update every second
        updateDateTime(); // Initial call to display immediately
    </script>
</body>
</html>
