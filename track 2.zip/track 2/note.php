<?php
session_start(); // Start the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Simple Notes</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #E7FBE6;
        }

        .container {
            max-width: 1500px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 10px;
            position: relative;
            z-index: 1;
        }

        .content {
            margin-bottom: 30px;
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            max-height: 500px; /* Set a max-height for scrolling */
            overflow-y: auto;  /* Enable vertical scrolling */
            
        }
        /* Scrollbar style for the .content container */
    .content::-webkit-scrollbar {
        width: 20px;
    }

    .content::-webkit-scrollbar-track {
        background: #e6ebeb;
        border-radius: 10px;
    }

    .content::-webkit-scrollbar-thumb {
        background-color: #B2B2B2;
        border-radius: 10px;
        border: 5px solid #ced4da;
    }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 10px;
            font-size: 18px;
            background-color: #ffffff;
            width: 100%;
            box-sizing: border-box;
        }

        /* ADD BUTTON */
        .btn-primary {
            border: none;
            padding: 9px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 17px;
            font-weight: bold;
            color: #fff;
            transition: background-color 0.3s ease, transform 0.3s ease;
            background-color: #088F8F;
            width: 20%;
        }

        .btn-primary:hover {
            background-color: #13bdbd;
            transform: scale(1.05);
        }

        /* EDIT AND DELETE BUTTON */
        .btn-edit, .btn-delete {
            border: none;
            padding: 5px 10px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            transition: background-color 0.3s ease, transform 0.3s ease;
            position: absolute;
            bottom: 15px;
        }

        .btn-edit {
            background-color: #3498db;
            right: 80px;
        }

        .btn-edit:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .btn-delete {
            background-color: #e74c3c;
            right: 10px;
        }

        .btn-delete:hover {
            background-color: #c0392b;
            transform: scale(1.05);
        }
        /* SAVE AND CANCEL BUTTON */
.btn-save, .btn-cancel {
    border: none;
    padding: 5px 10px; /* Same padding as edit/delete buttons */
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
    font-weight: bold;
    color: #fff;
    transition: background-color 0.3s ease, transform 0.3s ease;
    position: absolute; /* Positioning will depend on your layout */
    bottom: 15px; /* Adjust this as needed */
}

.btn-save {
    background-color: #2ecc71;
    right: 90px; /* Adjust right positioning as needed */
}

.btn-save:hover {
    background-color: #27ae60;
}

.btn-cancel {
    background-color: #d35400;
    right: 10px; /* Same as delete button */
}

.btn-cancel:hover {
    background-color: #c0392b;
}


        /* NOTE LISTS */
        .note-item {
            background: linear-gradient(to top, #afc9c9, #4e9191);
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
            position: relative;
            box-sizing: border-box;
            border: 5px solid #e6ebeb;
            height: 200px;
            display: flex;
            flex-direction: column;
            color: #fff;
        }

        /* DATE AND TIME */
        .note-time {
            font-size: 0.9em;
            text-align: center;
            margin-bottom: 10px;
            color: #e6ebeb;
        }

        .note-content {
            font-size: 1dvw;
            overflow-y: auto;
            max-height: 200px;
            word-wrap: break-word;
            padding-right: 10px;
        }

        /* scrollbar */
       
.note-content::-webkit-scrollbar {
    width: 8px; /* Matching the size of the one inside .note-item */
}

.note-content::-webkit-scrollbar-track {
    background: #e6ebeb; /* Make the track similar to the .note-item border color */
    border-radius: 8px;
}

.note-content::-webkit-scrollbar-thumb {
    background-color: #4e9191; /* Match the color to the gradient used in .note-item */
    border-radius: 8px;
    border: 2px solid #e6ebeb; /* Add a border for a more defined look */
}
#notes {
    background-color: #e6ebeb;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Adjust minimum size */
    gap: 20px;
}


        #no-notes {
            text-align: center;
            font-size: 1.2em;
            color: #888;
            margin-top: 20px;
        }

        .hidden {
            display: none;
        }

        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }

        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }

        @media (max-width: 700px) {
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                height: 100vh;
                background-color: white;
            }

            #logo {
                max-width: 60%;
                max-height: 60%;
                opacity: 0.3;
            }
        }
    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <img id="logo" src="user/images/logo.png" alt="Logo">
            <div class="container">
                <div class="content">
                    <textarea id="addTxt" class="form-control" rows="4" placeholder="Type your note here..."></textarea>
                    <div class="text-right mt-4">
                        <button id="addBtn" class="btn-primary">Add</button>
                    </div>
                </div>
                <hr class="separator">
                <div class="content">
                    <div id="notes">
                        <!-- Notes will be dynamically inserted here -->
                    </div>
                    <div id="no-notes">No Notes</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            loadNotes();
            document.getElementById('addBtn').addEventListener('click', function () {
                var noteContent = document.getElementById('addTxt').value;
                if (noteContent.trim()) {
                    var dateTime = new Date().toLocaleString();
                    addNoteToList(noteContent, dateTime);
                    saveNoteToLocalStorage(noteContent, dateTime);
                    document.getElementById('addTxt').value = '';
                }
            });
        });

        function addNoteToList(content, dateTime, index = null) {
            var noteList = document.getElementById('notes');
            var noteItem = document.createElement('div');
            noteItem.className = 'note-item';
            noteItem.dataset.index = index !== null ? index : noteList.children.length;
            noteItem.innerHTML = `
                <div class='note-time'>${dateTime}</div>
                <div class='note-content' contenteditable="false">${content}</div>
                <button class='btn-edit'>Edit</button>
                <button class='btn-delete'>Delete</button>
                <button class='btn-save hidden'>Save</button>
                <button class='btn-cancel hidden'>Cancel</button>
            `;
            noteList.appendChild(noteItem);
            updateNotesListVisibility();
        }

        function saveNoteToLocalStorage(content, dateTime) {
            var notes = JSON.parse(localStorage.getItem('notes')) || [];
            notes.push({ content, dateTime });
            localStorage.setItem('notes', JSON.stringify(notes));
        }

        function loadNotes() {
            var notes = JSON.parse(localStorage.getItem('notes')) || [];
            notes.forEach((note, index) => addNoteToList(note.content, note.dateTime, index));
            updateNotesListVisibility();
        }

        function updateNoteInLocalStorage(content, index) {
            var notes = JSON.parse(localStorage.getItem('notes')) || [];
            notes[index].content = content;
            notes[index].dateTime = new Date().toLocaleString(); // Update the date and time on save
            localStorage.setItem('notes', JSON.stringify(notes));
        }

        function deleteNoteFromLocalStorage(index) {
            var notes = JSON.parse(localStorage.getItem('notes')) || [];
            notes.splice(index, 1);
            localStorage.setItem('notes', JSON.stringify(notes));
        }

        function updateNotesListVisibility() {
            var notesContainer = document.getElementById('notes');
            var noNotesMessage = document.getElementById('no-notes');
            if (notesContainer.children.length === 0) {
                notesContainer.classList.add('hidden');
                noNotesMessage.classList.remove('hidden');
            } else {
                notesContainer.classList.remove('hidden');
                noNotesMessage.classList.add('hidden');
            }
        }

        document.addEventListener('click', function (e) {
            if (e.target.classList.contains('btn-edit')) {
                var noteItem = e.target.closest('.note-item');
                var noteContent = noteItem.querySelector('.note-content');
                var originalContent = noteContent.innerHTML;
                noteContent.contentEditable = true;
                noteContent.focus();
                e.target.classList.add('hidden');
                noteItem.querySelector('.btn-delete').classList.add('hidden');
                noteItem.querySelector('.btn-save').classList.remove('hidden');
                noteItem.querySelector('.btn-cancel').classList.remove('hidden');

                // Handle cancel action
                noteItem.querySelector('.btn-cancel').onclick = function () {
                    noteContent.innerHTML = originalContent; // Revert to original content
                    noteContent.contentEditable = false;
                    e.target.classList.remove('hidden');
                    noteItem.querySelector('.btn-delete').classList.remove('hidden');
                    noteItem.querySelector('.btn-save').classList.add('hidden');
                    noteItem.querySelector('.btn-cancel').classList.add('hidden');
                };
            }

            if (e.target.classList.contains('btn-save')) {
                var noteItem = e.target.closest('.note-item');
                var noteContent = noteItem.querySelector('.note-content');
                var index = noteItem.dataset.index;
                var updatedContent = noteContent.innerHTML;
                noteContent.contentEditable = false;
                e.target.classList.add('hidden');
                noteItem.querySelector('.btn-delete').classList.remove('hidden');
                noteItem.querySelector('.btn-edit').classList.remove('hidden');
                noteItem.querySelector('.btn-cancel').classList.add('hidden');
                updateNoteInLocalStorage(updatedContent, index);
                noteItem.querySelector('.note-time').innerHTML = new Date().toLocaleString(); // Update the displayed time
            }

            if (e.target.classList.contains('btn-delete')) {
                var noteItem = e.target.closest('.note-item');
                var index = noteItem.dataset.index;
                noteItem.remove();
                deleteNoteFromLocalStorage(index);
                updateNotesListVisibility();
                adjustNoteIndices();
            }
        });

        function adjustNoteIndices() {
            var notes = document.querySelectorAll('.note-item');
            notes.forEach((note, index) => {
                note.dataset.index = index;
            });
        }
    </script>
</body>
</html>