<?php 
session_start();
 
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your MySQL password if set
$dbname = "user_db";
 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
// Initialize or get existing registered pets array from session
$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];
$editIndex = isset($_GET['editIndex']) ? intval($_GET['editIndex']) : null;
$editPet = $editIndex !== null && isset($registeredPets[$editIndex]) ? $registeredPets[$editIndex] : null;
 
// Process registration form, delete, and update requests
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["deleteIndex"]) && is_numeric($_POST["deleteIndex"])) {
        $deleteIndex = $_POST["deleteIndex"];
        if (isset($registeredPets[$deleteIndex])) {
            unset($registeredPets[$deleteIndex]);
            $registeredPets = array_values($registeredPets);
            $_SESSION["registeredPets"] = $registeredPets;
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        }
    } elseif (isset($_POST["updateIndex"]) && is_numeric($_POST["updateIndex"])) {
        $updateIndex = $_POST["updateIndex"];
        if (isset($registeredPets[$updateIndex])) {
            $updatedPet = [
                "petName" => $_POST["petName"],
                "petAge" => $_POST["petAge"],
                "ownerName" => $_POST["ownerName"],
                "status" => $_POST["status"]
            ];
            $registeredPets[$updateIndex] = $updatedPet;
            $_SESSION["registeredPets"] = $registeredPets;
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        }
    } else {
        // Add new pet
        $newPet = [
            "petName" => $_POST["petName"],
            "petAge" => $_POST["petAge"],
            "ownerName" => $_POST["ownerName"],
            "status" => $_POST["status"]
        ];
        $registeredPets[] = $newPet;
        $_SESSION["registeredPets"] = $registeredPets;
        header("Location: " . $_SERVER["PHP_SELF"]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Registration</title>
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #E7FBE6;
        }
 
        .main-content {
        flex: 1;
        padding: 20px;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        max-width: 1200px;
        box-sizing: border-box;
        margin: 0 auto;
        position: relative;
        height: 100vh;
        padding: 20px;
        gap: 20px; /* Increase gap for a more spacious layout */
    }
        .form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 10px;
        }
        .form-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .form-group label {
            font-weight: bold;
            margin-right: 5px;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #088F8F;
            width: 150px; /* Fixed width for form elements */
        }
        .pet-list { 
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 1200px;
            overflow-y: auto;
        }
        .pet-list h2 {
    text-align: center; 
    margin-bottom: 20px; 
    font-weight: bold; 
    font-size: 1.5rem; 
}

.pet-list h2::after {
    content: ""; 
    display: block;
    width: 50%; 
    height: 2px; 
    background-color: teal; 
    margin: 0 auto; 
}

        .pet-list table {
            width: 100%;
            border-collapse: collapse;
        }
        .pet-list th, .pet-list td {
            padding: 15px;
            text-align: left;
        }
        .pet-list th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .status.active {
            color: #2ecc71; /* Green for Active */
        }
        .status.inactive {
            color: #e74c3c; /* Red for Inactive */
        }
        .icon-btn {
            cursor: pointer;
            font-size: 20px;
            color: #3498db; /* Color for icons */
            transition: color 0.3s ease;
        }
        .icon-btn:hover {
            color: #2980b9; /* Darker blue on hover */
        }
        
        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }
 
        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }
        @media (max-width: 700px) {
            span {
                display: none;
            }
 
            #sidebar {
                width: 10%;
                height: 100vh;
                background-color: white;
            }
 
            #logo {
                max-width: 60%;
                max-height: 60%;
                opacity: 0.3;
            }
        }
    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <img id="logo" src="user/images/logo.png" alt="Logo">
            <div class="main-content">
                <!-- Form for adding/updating pet -->
                <div class="form">
                    <form method="post" id="petForm" style="flex: 1; display: flex; gap: 10px;">
                        <input type="hidden" name="updateIndex" value="<?php echo $editIndex; ?>">

                        <div class="form-group">
                            <label for="petName">Pet Name</label>
                            <input type="text" id="petName" name="petName" value="<?php echo htmlspecialchars($editPet['petName'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="petAge">Pet Age</label>
                            <input type="number" id="petAge" name="petAge" value="<?php echo htmlspecialchars($editPet['petAge'] ?? ''); ?>" required min="1" max="30">
                        </div>
                        <div class="form-group">
                            <label for="ownerName">Owner Name</label>
                            <input type="text" id="ownerName" name="ownerName" value="<?php echo htmlspecialchars($editPet['ownerName'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" required>
                                <option value="active" <?php echo (isset($editPet) && $editPet['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo (isset($editPet) && $editPet['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        <div class="form-group">
                                <input type="submit" value="<?php echo $editPet ? 'Update Pet' : 'Add Pet'; ?>" class="bg-teal text-black font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-teal-700 transition duration-300 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-opacity-50">
                        </div>

                    </form>
                </div>

                <!-- List of registered pets -->
                <div class="pet-list">
                    <h2>Our Pets</h2>
                    <?php if (empty($registeredPets)): ?>
                        <p>No pets added.</p>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Pet Name</th>
                                    <th>Pet Age</th>
                                    <th>Owner Name</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registeredPets as $index => $pet): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($pet['petName']); ?></td>
                                        <td><?php echo htmlspecialchars($pet['petAge']); ?></td>
                                        <td><?php echo htmlspecialchars($pet['ownerName']); ?></td>
                                        <td class="status <?php echo $pet['status']; ?>"><?php echo ucfirst($pet['status']); ?></td>
                                        <td>
                                            <span class="icon-btn" onclick="location.href='?editIndex=<?php echo $index; ?>'"><i class='bx bxs-edit'></i></span>
                                            <span class="icon-btn" onclick="if(confirm('Are you sure you want to delete this pet?')) { document.getElementById('deleteForm<?php echo $index; ?>').submit(); }"><i class='bx bxs-trash'></i></span>
                                            <form id="deleteForm<?php echo $index; ?>" method="post" style="display:none;">
                                                <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>" 