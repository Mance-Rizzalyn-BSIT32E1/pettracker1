<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <title>Login</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: "Oswald", sans-serif;
            background: url('./images/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            background-attachment: fixed;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: start;
            width: 100%;
            height: 100%;
        }

        /* Header styles */
        .header {
            font-size: 5vw; /* Responsive font size */
            text-align: center;
            margin-top: 10vh; /* Adjust top margin for spacing */
            font-style: italic;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3); /* Adjusted text shadow */
        }

        .login, .signup {
            background-color: black;
            color: white;
            margin: 10px; /* Add margin to create distance */
            border-radius: 30px;
            padding: 10px 30px; /* Responsive padding */
            font-size: 18px; /* Fixed font size */
            text-align: center;
            text-decoration: none; /* Remove default underline */
        }

        @media (max-width: 768px) {
            .container {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                width: 100%;
                height: 100%;
            }

            .header {
                font-size: xxx-large;
            }

        }

    </style>
</head>
<body>
    <div class="container">
        <h1 class="header">PetTracker</h1>
        <a href="./user/login.php" class="login">Log In</a>
        <a href="./user/register.php" class="signup">Sign Up</a>
    </div>
    <script src="./javascript/sessionmessage.js"></script>
</body>
</html>
