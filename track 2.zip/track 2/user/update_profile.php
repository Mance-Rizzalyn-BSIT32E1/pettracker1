<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if (isset($_POST['update_profile'])) {

   $update_name = mysqli_real_escape_string($conn, $_POST['update_name']);
   $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);

   mysqli_query($conn, "UPDATE user_form SET name = '$update_name', email = '$update_email' WHERE id = '$user_id'") or die('Query failed: ' . mysqli_error($conn));

   $old_pass = $_POST['old_pass'];
   $update_pass = mysqli_real_escape_string($conn, md5($_POST['update_pass']));
   $new_pass = mysqli_real_escape_string($conn, md5($_POST['new_pass']));
   $confirm_pass = mysqli_real_escape_string($conn, md5($_POST['confirm_pass']));

   if (!empty($update_pass) || !empty($new_pass) || !empty($confirm_pass)) {
      if ($update_pass != $old_pass) {
         $message[] = 'Old password does not match!';
      } elseif ($new_pass != $confirm_pass) {
         $message[] = 'Confirm password does not match!';
      } else {
         mysqli_query($conn, "UPDATE user_form SET password = '$confirm_pass' WHERE id = '$user_id'") or die('Query failed: ' . mysqli_error($conn));
         $message[] = 'Password updated successfully!';
      }
   }

   $message[] = 'Profile updated successfully!';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <title>Update Profile</title>
   <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

   <style>
      body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #E7FBE6;
        }

      .container {
         display: flex;
         height: 100vh;
         position: relative;
         z-index: 1;
      }

      .main-content {
         margin-bottom: 30px;
         padding: 20px;
         flex: 1;
         display: flex;
         align-items: center;
         justify-content: center;
         position: relative;
         margin-right: -600px;
      }

      .update-profile {
         background-color: #fff;
         padding: 30px;
         border-radius: 10px;
         box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
         width: 100%;
         max-width: 600px;
         z-index: 1; /* Ensure form is above the logo */
      position: relative;
      }

      .update-profile h2 {
         font-size: 24px;
         font-weight: 600;
         margin-bottom: 20px;
         color: #333;
         text-align: center;
         padding: 10px;
      }

      .inputBox {
         margin-bottom: 20px;
      }

      .inputBox span {
         display: block;
         margin-bottom: 8px;
         font-size: 16px;
         color: #333;
      }

      .inputBox .box {
         width: 100%;
         padding: 12px;
         font-size: 16px;
         color: #555;
         border: 1px solid #ccc;
         border-radius: 5px;
         box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
      }

      .btn {
         display: block;
         width: 100%;
         padding: 12px;
         background-color: #17b890;
         color: #fff;
         border: none;
         border-radius: 5px;
         font-size: 18px;
         cursor: pointer;
         transition: background-color 0.3s ease;
         margin-top: 10px;
         text-align: center;
      }

      .btn:hover {
         background-color: #159d7f;
      }

      .delete-btn {
         display: block;
         width: 100%;
         padding: 12px;
         background-color: #f44336;
         color: #fff;
         border: none;
         border-radius: 5px;
         font-size: 18px;
         cursor: pointer;
         transition: background-color 0.3s ease;
         margin-top: 10px;
         text-align: center;
         text-decoration: none;
      }

      .delete-btn:hover {
         background-color: #d32f2f;
      }

      .message {
         background-color: #ffcc00;
         color: #333;
         padding: 10px;
         border-radius: 5px;
         margin-bottom: 15px;
         text-align: center;
      }
      
      #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }
        #logo {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    height: 100%;
    object-fit: contain;
    opacity: 0.4;
    z-index: 0;
}

        @media (max-width: 700px) {
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                height: 100vh;
                background-color: white;
            }
            #logo {
        max-width: 60%;
        max-height: 60%;
        opacity: 0.3;
    }
        }
   </style>
</head>

<body>

   <div class="container">
      <div id="sidebar">
         <?php include('../sidebar-2.php'); ?>
      </div>
      <div class="main-content">
      <img id="logo" src="../user/images/image.png" alt="Logo">
         <div class="update-profile">

            <?php
            $select = mysqli_query($conn, "SELECT * FROM user_form WHERE id = '$user_id'") or die('Query failed: ' . mysqli_error($conn));
            if (mysqli_num_rows($select) > 0) {
               $fetch = mysqli_fetch_assoc($select);
            }
            ?>

            <h2>Update Profile</h2>

            <form action="" method="post">
               <?php
               if (isset($message)) {
                  foreach ($message as $msg) {
                     echo '<div class="message">' . $msg . '</div>';
                  }
               }
               ?>
               <div class="inputBox">
                  <span>Username:</span>
                  <input type="text" name="update_name" value="<?php echo $fetch['name']; ?>" class="box" required>
               </div>
               <div class="inputBox">
                  <span>Email Address:</span>
                  <input type="email" name="update_email" value="<?php echo $fetch['email']; ?>" class="box" required>
               </div>
               <div class="inputBox">
                  <span>Old Password:</span>
                  <input type="text" name="update_pass" placeholder="Enter previous password" class="box">
                  <input type="hidden" name="old_pass" value="<?php echo $fetch['password']; ?>">
               </div>
               <div class="inputBox">
                  <span>New Password:</span>
                  <input type="text" name="new_pass" placeholder="Enter new password" class="box">
               </div>
               <div class="inputBox">
                  <span>Confirm Password:</span>
                  <input type="text" name="confirm_pass" placeholder="Confirm new password" class="box">
               </div>
               <input type="submit" value="Update Profile" name="update_profile" class="btn">
               <a href="../MainDashboard.php" class="delete-btn">Go Back</a>
            </form>

         </div>
      </div>
   </div>

</body>

</html>
